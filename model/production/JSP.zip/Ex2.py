import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from collections import defaultdict, deque
import openpyxl
import random
import copy
from typing import List, Dict, Tuple, Set, Optional
import time
import pandas as pd
from Ex1 import Job, DisjunctiveGraph, ScheduleSolver, Operation

MACHINE_LIST = ['C1', 'C2', 'C3', 'C4', 'L1', 'PM1', 'NYM1', 'WYM1', 'RCL1', 'RCL2', 'WX1', 'LX1', 'LX2', 'LX3', 'Z1', 'Z2', 'DHH1', 'XQG1', 'JC1', 'QG1']


def validate_job_data(job_data: List[Tuple[List[int], List[int]]], num_jobs: int, num_machines: int) -> List[Job]:
    """
    验证工件数据并创建工件对象
    
    Args:
        job_data: 工件数据列表
        num_jobs: 工件数量
        num_machines: 机器数量
        
    Returns:
        List[Job]: 验证后的工件对象列表
    """
    print("正在验证数据完整性...")
    
    # 检查数据合理性
    for i, (machines, times) in enumerate(job_data):
        if len(machines) != len(times):
            raise ValueError(f"工件 {i+1} 的机器和时间数据长度不匹配")
        
        if any(t <= 0 for t in times):
            print(f"警告: 工件 {i+1} 包含非正数加工时间")
        
        if any(m < 1 for m in machines):
            print(f"警告: 工件 {i+1} 包含无效机器编号")
    
    # 创建工件对象
    jobs = []
    for i, (machines, times) in enumerate(job_data):
        try:
            job = Job(i + 1, machines, times)
            jobs.append(job)
            if i < 3:
                print(f"工件 {i+1}: 机器序列长度={len(machines)}, 加工时间范围=[{min(times)}, {max(times)}]")
        except Exception as e:
            raise ValueError(f"创建工件 {i+1} 时发生错误: {e}")
    
    return jobs

def build_disjunctive_graph_and_solver(jobs: List[Job]) -> Tuple[DisjunctiveGraph, ScheduleSolver]:
    """
    构建析取图和求解器
    
    Args:
        jobs: 工件列表
        
    Returns:
        Tuple[DisjunctiveGraph, ScheduleSolver]: 析取图和求解器
    """
    try:
        graph = DisjunctiveGraph(jobs)
        solver = ScheduleSolver(graph)
        
        print(f"\n析取图构建完成:")
        print(f"- 工序总数: {len(graph.operations)}")
        print(f"- 连接弧数量: {len(graph.conjunctive_arcs)}")
        print(f"- 析取弧数量: {len(graph.disjunctive_arcs)}")
        
        # 验证机器操作分布
        print(f"- 各机器上的工序数量:")
        for machine in sorted(graph.machine_operations.keys()):
            ops_count = len(graph.machine_operations[machine])
            print(f"  机器 M{machine}: {ops_count} 个工序")
            
        return graph, solver
        
    except Exception as e:
        raise ValueError(f"构建析取图时发生错误: {e}")

def solve_and_visualize(solver: ScheduleSolver, dataset_name: str, num_jobs: int, max_iterations: int, max_attempts: int) -> Dict[str, Tuple]:
    """
    求解调度问题并可视化结果
    
    Args:
        solver: 调度求解器
        dataset_name: 数据集名称
        num_jobs: 工件数量
        max_iterations: 最大迭代次数
        max_attempts: 最大尝试次数
        
    Returns:
        Dict[str, Tuple]: 求解结果
    """
    print(f"\n运行随机搜索算法 (最大迭代次数: {max_iterations})...")
    
    try:
        start_time = time.time()
        best_makespan_rs, best_orders_rs = solver.random_search(max_iterations=max_iterations, max_attempts=max_attempts)
        rs_time = time.time() - start_time
        
        if best_makespan_rs != float('inf'):
            print(f"随机搜索完成: Makespan = {best_makespan_rs}, 时间 = {rs_time:.3f}s")
            
            # 生成甘特图
            print(f"\n正在为 {dataset_name} 生成甘特图...")
            try:
                _, start_times = solver.calculate_makespan(best_orders_rs)
                visualize_schedule(best_orders_rs, start_times, 
                                    f"{dataset_name} - 随机搜索 (Makespan = {best_makespan_rs})")
                
                # 显示调度详情
                if num_jobs <= 10:  # 只对小规模问题显示详细信息
                    print_schedule_details(best_orders_rs, start_times, best_makespan_rs)
                    
            except Exception as e:
                print(f"生成甘特图时出错: {e}")
                
            return {'随机搜索': (best_makespan_rs, rs_time)}
        else:
            print(f"随机搜索未找到有效解")
            return {'随机搜索': (None, None)}
            
    except Exception as e:
        print(f"随机搜索执行出错: {e}")
        return {'随机搜索': (None, None)}

def read_real_case_data(filename: str) -> Tuple[List[Job], Dict[str, str]]:
    """
    读取实际案例Excel数据
    
    Args:
        filename: Excel文件路径
        
    Returns:
        (jobs, machine_mapping): 柔性工件列表和机器映射表
    """

    # 使用openpyxl读取Excel文件
    workbook = openpyxl.load_workbook(filename)
    worksheet = workbook.active
    
    print(f"读取Excel文件: {filename}")
    print(f"工作表名称: {worksheet.title}")
    print(f"数据范围: {worksheet.max_row} 行 x {worksheet.max_column} 列")
    
    # 解析数据结构
    jobs = []
    machine_mapping = {}
    
    # 从第5行开始读取数据
    current_job_id = 1
    current_job_operations = []
    current_quantity = 1
    
    # 机器列名映射 (F列开始对应所有机器，E列是工序序号)
    machine_columns = MACHINE_LIST
    part_name = ""
    for row in range(6, worksheet.max_row + 1):  # 从第6行开始

        # 读取各列数据
        cur_part_name = worksheet.cell(row=row, column=2).value  # B列：零件名称
        
        cur_quantity = worksheet.cell(row=row, column=3).value   # C列：数量
        feature = worksheet.cell(row=row, column=4).value    # D列：特征
        operation_seq = worksheet.cell(row=row, column=5).value  # E列：工序序号
        feature = str(feature).strip() if feature else ""
        
        # 处理数量
        quantity = int(float(str(cur_quantity).strip())) if cur_quantity else quantity
        
        # 处理工序序号
        operation_seq = int(float(str(operation_seq).strip())) if operation_seq else 0

        # 检查是否开始新工件（B列出现新值）
        if cur_part_name is not None and part_name != cur_part_name:
            
            # 创建前一个工件（根据数量创建多个相同工件）
            if current_job_operations:
                for i in range(current_quantity):
                    print(f"添加工件 {current_job_id}，零件={part_name}, 工序数={len(current_job_operations)}")
                    job = FlexibleJob(current_job_id, copy.deepcopy(current_job_operations))
                    jobs.append(job)
                    current_job_id += 1
            part_name = str(cur_part_name).strip() if cur_part_name else part_name
            current_job_operations = []

        current_quantity = quantity
        
        # 解析机器选项和时间（从F列开始）
        machine_options = []
        
        # 读取F列到后续列的机器时间数据
        for i, machine_name in enumerate(machine_columns):
            col_idx = 6 + i  # F列开始（索引6）
            cell_value = worksheet.cell(row=row, column=col_idx).value
            
            if cell_value is not None and str(cell_value).strip() != '':
                try:
                    time_val = int(float(str(cell_value).strip()))
                    if time_val > 0:  # 只添加正数时间
                        machine_options.append((machine_name, time_val))
                except (ValueError, TypeError):
                    continue
        
        # print(f"行 {row}: 零件={part_name}, 特征={feature}, 工序序号={operation_seq}, 机器选项={machine_options}")
        
        # 如果有有效的机器选项，创建工序
        if machine_options and operation_seq > 0:
            # 使用Excel中的工序序号
            operation = FlexibleOperation(current_job_id, operation_seq, machine_options)
            print(operation)
            current_job_operations.append(operation)
    
    # 添加最后一个工件（根据数量创建多个相同工件）
    if current_job_operations:
        for i in range(current_quantity):
            job = FlexibleJob(current_job_id, copy.deepcopy(current_job_operations))
            jobs.append(job)
            current_job_id += 1
            print(f"添加工件 {current_job_id}，零件={part_name}, 工序数={len(current_job_operations)}")

    # 创建机器映射
    all_machines = set()
    for job in jobs:
        for op in job.operations:
            for machine, _ in op.machine_options:
                all_machines.add(machine)
    
    machine_mapping = {machine: machine for machine in sorted(all_machines)}
    
    print(f"\n解析完成:")
    print(f"工件数量: {len(jobs)}")
    print(f"机器数量: {len(machine_mapping)}")
    print(f"机器列表: {sorted(machine_mapping.keys())}")
    
    workbook.close()
    return jobs, machine_mapping
        
class FlexibleOperation:
    """柔性工序类 - 支持多机器选择的工序，使用三维析取图表示"""
    def __init__(self, job_id: int, op_index: int, machine_options: List[Tuple[str, int]]):
        self.job_id = job_id
        self.op_index = op_index
        self.machine_options = machine_options  # [(machine_id, processing_time), ...]
        self.selected_machine = None
        self.selected_time = None
        self.id = f"O_{job_id}_{op_index}"
        
        # 按加工时间分组机器选项，构建第三维度
        self.machine_groups = self._group_machines_by_time()
        
        # 为每个机器组创建虚拟工序ID
        self.virtual_ops = {}
        for time, machines in self.machine_groups.items():
            group_id = f"O_{job_id}_{op_index}_T{time}"
            self.virtual_ops[group_id] = {
                'time': time,
                'machines': machines,
                'group_id': group_id
            }
    
    def _group_machines_by_time(self) -> Dict[int, List[str]]:
        """按加工时间对机器进行分组"""
        groups = defaultdict(list)
        for machine, time in self.machine_options:
            groups[time].append(machine)
        return dict(groups)
    
    def select_machine_from_group(self, time_group: int) -> Optional[str]:
        """从指定时间组中随机选择一台机器"""
        if time_group not in self.machine_groups:
            return None
        
        machines = self.machine_groups[time_group]
        selected_machine = random.choice(machines)
        
        self.selected_machine = selected_machine
        self.selected_time = time_group
        return selected_machine
    
    def get_time_groups(self) -> List[int]:
        """获取所有可用的时间组"""
        return list(self.machine_groups.keys())
    
    def get_best_time_group(self) -> Tuple[int, List[str]]:
        """获取加工时间最短的机器组"""
        if not self.machine_groups:
            return None, []
        
        best_time = min(self.machine_groups.keys())
        return best_time, self.machine_groups[best_time]
    
    def __str__(self):
        groups_info = []
        for time, machines in self.machine_groups.items():
            groups_info.append(f"T{time}: {machines}")
        return f"{self.id}(J{self.job_id}, Groups: {groups_info})"

class FlexibleJob:
    """柔性工件类"""
    def __init__(self, job_id: int, operations: List[FlexibleOperation]):
        self.job_id = job_id
        self.operations = operations
        self.name = f"Job_{job_id}"
    
    def __str__(self):
        return f"FlexibleJob {self.job_id}: {len(self.operations)} operations"

class ExtendedOperation:
    """扩展工序类 - 用于处理柔性JSP的虚拟工序"""
    def __init__(self, job_id: int, op_index: int, machine: int, processing_time: int, 
                 is_virtual: bool = False, original_op_id: str = None):
        self.job_id = job_id
        self.op_index = op_index
        self.machine = machine
        self.processing_time = processing_time
        self.is_virtual = is_virtual
        self.original_op_id = original_op_id  # 对应的原始柔性工序ID
        self.id = f"O_{job_id}_{op_index}_{machine}" if is_virtual else f"O_{job_id}_{op_index}"
    
    def __str__(self):
        prefix = "V" if self.is_virtual else "O"
        return f"{prefix}_{self.job_id}_{self.op_index}(M{self.machine}, t={self.processing_time})"
    
    def __repr__(self):
        return self.__str__()

class Extended3DOperation:
    """三维扩展工序类 - 用于处理柔性JSP的三维虚拟工序"""
    def __init__(self, job_id: int, op_index: int, time_group: int, machine_group: List[str], 
                 is_virtual: bool = False, original_op_id: str = None):
        self.job_id = job_id
        self.op_index = op_index
        self.time_group = time_group  # 第三维度：时间组
        self.machine_group = machine_group  # 该时间组内的机器列表
        self.selected_machine = None  # 采样时选中的具体机器
        self.selected_machine_id = None  # 选中机器的数字ID
        self.processing_time = time_group
        self.is_virtual = is_virtual
        self.original_op_id = original_op_id
        self.id = f"O_{job_id}_{op_index}_T{time_group}" if is_virtual else f"O_{job_id}_{op_index}"
    
    def sample_machine(self) -> str:
        """从机器组中随机采样一台机器"""
        if not self.machine_group:
            return None
        
        self.selected_machine = random.choice(self.machine_group)
        self.selected_machine_id = self._machine_name_to_id(self.selected_machine)
        return self.selected_machine
    
    def _machine_name_to_id(self, machine_name: str) -> int:
        """将机器名称转换为数字ID"""
        try:
            return MACHINE_LIST.index(machine_name) + 1
        except ValueError:
            return len(MACHINE_LIST) + 1
    
    def get_standard_operation(self):
        """转换为标准工序对象"""
        if self.selected_machine_id is None:
            self.sample_machine()
        
        from Ex1 import Operation
        return Operation(self.job_id, self.op_index, self.selected_machine_id, self.processing_time)
    
    def __str__(self):
        machine_info = f"Selected: {self.selected_machine}" if self.selected_machine else f"Group: {self.machine_group}"
        prefix = "3D" if self.is_virtual else "O"
        return f"{prefix}_{self.job_id}_{self.op_index}_T{self.time_group}({machine_info}, t={self.processing_time})"
    
    def __repr__(self):
        return self.__str__()

class Flexible3DDisjunctiveGraph:
    """三维柔性析取图类 - 处理柔性JSP问题的三维表示"""
    def __init__(self, flexible_jobs: List[FlexibleJob], machine_mapping: Dict[str, str]):
        self.flexible_jobs = flexible_jobs
        self.machine_mapping = machine_mapping
        self.virtual_3d_operations = []  # 所有三维虚拟工序
        self.conjunctive_arcs = []       # 工艺路径约束
        self.disjunctive_arcs = []       # 机器资源约束（按时间组）
        self.selection_groups = []       # 选择约束组（每个柔性工序对应一组时间组）
        self.time_group_operations = defaultdict(list)  # 按时间组分类的工序
        
        self._build_3d_graph()
    
    def _build_3d_graph(self):
        """构建三维析取图"""
        print("构建三维析取图...")
        
        # 第一步：为每个柔性工序的每个时间组创建三维虚拟工序
        for job in self.flexible_jobs:
            for flex_op in job.operations:
                selection_group = []
                
                for time_group, machine_list in flex_op.machine_groups.items():
                    # 创建三维虚拟工序
                    virtual_3d_op = Extended3DOperation(
                        job_id=flex_op.job_id,
                        op_index=flex_op.op_index,
                        time_group=time_group,
                        machine_group=machine_list,
                        is_virtual=True,
                        original_op_id=flex_op.id
                    )
                    
                    self.virtual_3d_operations.append(virtual_3d_op)
                    self.time_group_operations[time_group].append(virtual_3d_op)
                    selection_group.append(virtual_3d_op)
                
                # 记录选择组（每个柔性工序的所有时间组选项）
                if selection_group:
                    self.selection_groups.append(selection_group)
        
        # 第二步：构建工艺路径约束（连接弧）
        self._build_3d_process_constraints()
        
        # 第三步：构建时间组内的资源约束（析取弧）
        self._build_3d_machine_constraints()
        
        print(f"三维析取图构建完成:")
        print(f"- 三维虚拟工序总数: {len(self.virtual_3d_operations)}")
        print(f"- 时间组数量: {len(self.time_group_operations)}")
        print(f"- 选择组数量: {len(self.selection_groups)}")
        print(f"- 工艺约束弧数: {len(self.conjunctive_arcs)}")
        print(f"- 资源约束弧数: {len(self.disjunctive_arcs)}")
        
        # 输出时间组信息
        for time_group in sorted(self.time_group_operations.keys()):
            ops_count = len(self.time_group_operations[time_group])
            print(f"- 时间组 T{time_group}: {ops_count} 个工序")
    
    def _build_3d_process_constraints(self):
        """构建三维工艺路径约束"""
        for job in self.flexible_jobs:
            for i in range(len(job.operations) - 1):
                current_flex_op = job.operations[i]
                next_flex_op = job.operations[i + 1]
                
                # 获取当前工序和下一工序的所有三维虚拟工序
                current_3d_ops = [op for op in self.virtual_3d_operations 
                                if op.original_op_id == current_flex_op.id]
                next_3d_ops = [op for op in self.virtual_3d_operations 
                             if op.original_op_id == next_flex_op.id]
                
                # 每个当前三维工序都必须连接到下一个工序的所有三维工序
                for curr_op in current_3d_ops:
                    for next_op in next_3d_ops:
                        self.conjunctive_arcs.append((curr_op, next_op, curr_op.processing_time))
    
    def _build_3d_machine_constraints(self):
        """构建三维机器资源约束 - 考虑机器采样后的冲突"""
        # 注意：在三维表示中，真正的机器冲突只有在采样确定具体机器后才能确定
        # 这里我们先建立时间组级别的约束，具体机器冲突在采样时处理
        pass
    
    def sample_valid_3d_solution(self, max_attempts: int = 5000) -> Dict:
        """采样一个有效的三维柔性JSP解决方案"""
        for attempt in range(max_attempts):
            try:
                # 第一步：为每个选择组选择一个时间组（三维虚拟工序）
                selected_3d_operations = []
                selection_map = {}  # original_op_id -> selected_3d_op
                
                for group in self.selection_groups:
                    if not group:
                        continue
                    # 从时间组中选择（优先选择时间短的）
                    selected_3d_op = self._select_from_3d_group(group)
                    selected_3d_operations.append(selected_3d_op)
                    selection_map[selected_3d_op.original_op_id] = selected_3d_op
                
                # 第二步：为每个选中的三维工序采样具体机器
                machine_conflicts = self._sample_machines_and_check_conflicts(selected_3d_operations)
                
                if machine_conflicts:
                    continue  # 有冲突，重新采样
                
                # 第三步：构建基于采样结果的标准JSP问题
                standard_jobs = self._create_standard_jobs_from_3d_selection(selection_map)
                
                if not standard_jobs:
                    continue
                
                # 第四步：求解标准JSP
                graph = DisjunctiveGraph(standard_jobs)
                machine_orders = graph.sample_valid_machine_order(max_attempts=1000)
                
                if machine_orders:
                    solver = ScheduleSolver(graph)
                    makespan, start_times = solver.calculate_makespan(machine_orders)
                    
                    if makespan != float('inf'):
                        return {
                            'makespan': makespan,
                            '3d_selection': selection_map,
                            'machine_orders': machine_orders,
                            'start_times': start_times,
                            'standard_jobs': standard_jobs
                        }
            except Exception as e:
                continue
        
        return None
    
    def _select_from_3d_group(self, group: List[Extended3DOperation]) -> Extended3DOperation:
        """从三维选择组中选择一个时间组"""
        if len(group) == 1:
            return group[0]
        
        # 启发式：优先选择加工时间短的时间组
        weights = []
        for op in group:
            # 时间越短权重越高
            weight = 1.0 / (op.time_group + 1)
            # 添加随机扰动
            weight *= random.uniform(0.8, 1.2)
            weights.append(weight)
        
        # 加权随机选择
        total_weight = sum(weights)
        r = random.uniform(0, total_weight)
        cumulative = 0
        
        for op, weight in zip(group, weights):
            cumulative += weight
            if cumulative >= r:
                return op
        
        return group[-1]  # fallback
    
    def _sample_machines_and_check_conflicts(self, selected_3d_operations: List[Extended3DOperation]) -> bool:
        """为选中的三维工序采样具体机器，并检查是否有冲突"""
        # 记录每台机器在每个时间段的占用情况
        machine_schedules = defaultdict(list)
        
        # 为每个三维工序采样机器
        for op in selected_3d_operations:
            op.sample_machine()
        
        # 这里可以添加更复杂的冲突检测逻辑
        # 目前简化处理，假设采样的机器选择是有效的
        return False  # 无冲突
    
    def _create_standard_jobs_from_3d_selection(self, selection_map: Dict[str, Extended3DOperation]) -> List[Job]:
        """根据三维机器选择创建标准JSP工件"""
        standard_jobs = []
        
        for job in self.flexible_jobs:
            machines = []
            times = []
            
            # 按工序顺序收集选中的机器和时间
            for flex_op in job.operations:
                if flex_op.id in selection_map:
                    selected_3d_op = selection_map[flex_op.id]
                    # 确保已经采样了具体机器
                    if selected_3d_op.selected_machine_id is None:
                        selected_3d_op.sample_machine()
                    
                    machines.append(selected_3d_op.selected_machine_id)
                    times.append(selected_3d_op.processing_time)
            
            if machines and times:
                standard_job = Job(job.job_id, machines, times)
                standard_jobs.append(standard_job)
        
        return standard_jobs

class FlexibleScheduleSolver:
    """柔性作业车间调度求解器"""
    def __init__(self, flexible_jobs: List[FlexibleJob], machine_mapping: Dict[str, str]):
        self.flexible_jobs = flexible_jobs
        self.machine_mapping = machine_mapping
        self.best_makespan = float('inf')
        self.best_schedule = None
        
    def solve_flexible_jsp(self, max_iterations: int = 5000) -> Tuple[int, Dict]:
        """求解柔性作业车间调度问题"""
        print(f"开始求解柔性JSP问题...")
        print(f"柔性工件数量: {len(self.flexible_jobs)}")
        print(f"可用机器数量: {len(self.machine_mapping)}")
        
        # 创建扩展析取图
        extended_graph = Flexible3DDisjunctiveGraph(self.flexible_jobs, self.machine_mapping)
        
        best_makespan = float('inf')
        best_result = None
        valid_solutions = 0
        
        # 多次采样求解
        for iteration in range(max_iterations):
            result = extended_graph.sample_valid_3d_solution(max_attempts=100)
            
            if result:
                valid_solutions += 1
                makespan = result['makespan']
                
                if makespan < best_makespan:
                    best_makespan = makespan
                    best_result = result
                    print(f"第 {iteration+1} 次尝试找到更优解: Makespan = {best_makespan}")
            
            # 每1000次输出进度
            if (iteration + 1) % 1000 == 0:
                print(f"已完成 {iteration+1}/{max_iterations} 次尝试, 有效解: {valid_solutions}")
        
        print(f"求解完成! 总有效解: {valid_solutions}/{max_iterations}, 最优 Makespan: {best_makespan}")
        
        return best_makespan, best_result
    
    def _machine_id_to_name(self, machine_id: int) -> str:
        """将数字ID转换为机器名称"""
        if 1 <= machine_id <= len(MACHINE_LIST):
            return MACHINE_LIST[machine_id - 1]
        else:
            return f"Unknown_M{machine_id}"
    
    def save_solution_to_file(self, result: Dict, filename: str = "realcase_sol.txt"):
        """将解决方案保存到文件"""
        if not result or not result.get('machine_orders'):
            print("没有有效的解决方案可保存")
            return
        
        try:
            machine_orders = result['machine_orders']
            start_times = result['start_times']
            makespan = result['makespan']
            
            # 生成解决方案表格
            solution_data = []
            
            for machine_id in sorted(machine_orders.keys()):
                machine_name = self._machine_id_to_name(machine_id)
                operations = machine_orders[machine_id]
                
                for op in operations:
                    start_time = start_times[op.id]
                    end_time = start_time + op.processing_time;
                    
                    solution_data.append({
                        '设备编号': machine_name,
                        '零件编号': op.job_id,
                        '工序标号': op.op_index,
                        '开始时间': start_time,
                        '结束时间': end_time
                    })
            
            # 按设备编号和开始时间排序
            solution_data.sort(key=lambda x: (x['设备编号'], x['开始时间']))
            
            # 写入文件
            with open(filename, 'w', encoding='utf-8') as f:
                f.write("实际案例调度方案\n")
                f.write("="*50 + "\n")
                f.write(f"最大完工时间 (Makespan): {makespan}\n")
                f.write("="*50 + "\n\n")
                
                f.write("Solution表格:\n")
                f.write("-"*70 + "\n")
                f.write(f"{'设备编号':<10} {'零件编号':<10} {'工序标号':<10} {'开始时间':<10} {'结束时间':<10}\n")
                f.write("-"*70 + "\n")
                
                for row in solution_data:
                    f.write(f"{row['设备编号']:<10} {row['零件编号']:<10} {row['工序标号']:<10} "
                           f"{row['开始时间']:<10} {row['结束时间']:<10}\n")
                
                f.write("-"*70 + "\n")
                f.write(f"总计: {len(solution_data)} 个工序\n")
            
            print(f"解决方案已保存到 {filename}")
            
        except Exception as e:
            print(f"保存解决方案时发生错误: {e}")
            import traceback
            traceback.print_exc()

def solve_real_case(max_iterations: int = 5000):
    """求解实际案例"""
    print("开始处理实际案例数据...")
    
    # 读取Excel数据
    filename = "data/real_case.xlsx"
    flexible_jobs, machine_mapping = read_real_case_data(filename)
    if not flexible_jobs:
        print("未能成功读取数据，请检查Excel文件格式")
        return

    # 创建柔性调度求解器
    solver = FlexibleScheduleSolver(flexible_jobs, machine_mapping)

    # 求解问题
    makespan, result = solver.solve_flexible_jsp(max_iterations=max_iterations)

    if makespan != float('inf'):
        print(f"求解完成! 最优Makespan: {makespan}")
    
        # 保存解决方案
        solver.save_solution_to_file(result)
    
        # 可视化结果
        if result.get('machine_orders'):
            try:
                machine_orders = result['machine_orders']
                start_times = result['start_times']
            
                print("正在生成甘特图...")
                visualize_schedule(machine_orders, start_times, 
                                          f"实际案例调度方案 (Makespan = {makespan})")
            except Exception as e:
                print(f"生成甘特图时出错: {e}")
    else:
        print("未找到可行解")
    

def visualize_schedule(machine_orders: Dict[int, List[Operation]], 
                      start_times: Dict[str, int], 
                      title: str = "作业车间调度甘特图"):
    """
    可视化调度方案的甘特图
    
    Args:
        machine_orders: 每台机器的工序顺序
        start_times: 各工序的开始时间
        title: 图表标题
    """
    # 检查输入数据
    if not machine_orders or not start_times:
        print("无效的调度数据，无法生成甘特图")
        return
        
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # 扩展颜色映射（为不同工件分配不同颜色）
    colors = [
        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', 
        '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
        '#F8C471', '#82E0AA', '#F1948A', '#85C1E9', '#D2B4DE',
        '#AED6F1', '#A3E4D7', '#D5DBDB', '#FADBD8', '#D1F2EB',
        '#FCF3CF', '#EBDEF0', '#EAF2F8', '#E8F8F5', '#FDF2E9'
    ]
    job_colors = {}
    
    machines = sorted(machine_orders.keys())
    y_positions = {machine: i for i, machine in enumerate(machines)}
    
    # 计算最大时间用于设置x轴
    max_time = max(start_times[op.id] + op.processing_time 
                  for ops in machine_orders.values() for op in ops)
    
    # 绘制甘特图
    for machine, operations in machine_orders.items():
        y_pos = y_positions[machine]
        
        for op in operations:
            job_id = op.job_id
            if job_id not in job_colors:
                job_colors[job_id] = colors[len(job_colors) % len(colors)]
            
            start_time = start_times[op.id]
            duration = op.processing_time
            
            # 绘制工序矩形 - 去掉文字标签
            rect = patches.Rectangle((start_time, y_pos - 0.35), duration, 0.7,
                                   linewidth=1.5, edgecolor='white', 
                                   facecolor=job_colors[job_id], alpha=0.8)
            ax.add_patch(rect)
    
    # 设置图表属性
    ax.set_xlabel('Time', fontsize=16, fontweight='bold')
    ax.set_ylabel('Machine', fontsize=16, fontweight='bold')
    ax.set_title(title, fontsize=18, fontweight='bold', pad=20)
    
    # 设置y轴
    ax.set_yticks(range(len(machines)))
    ax.set_yticklabels([f'M{m}' for m in machines], fontsize=14)
    ax.set_ylim(-0.5, len(machines) - 0.5)
    
    # 设置x轴
    ax.set_xlim(0, max_time + max_time * 0.05)  # 添加5%的边距
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=12)
    
    # 添加网格
    ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
    ax.set_axisbelow(True)
    
    # 添加图例 - 显示工件信息
    legend_elements = []
    for job_id in sorted(job_colors.keys()):
        legend_elements.append(
            patches.Patch(facecolor=job_colors[job_id], 
                         label=f'Job {job_id}', alpha=0.8,
                         edgecolor='white', linewidth=1)
        )
    
    # 将图例放在图表右侧
    ax.legend(handles=legend_elements, loc='center left', 
             bbox_to_anchor=(1.02, 0.5), fontsize=12,
             title='Jobs', title_fontsize=14)
    
    # 添加makespan标记线
    ax.axvline(x=max_time, color='red', linestyle='--', linewidth=3, alpha=0.8)
    ax.text(max_time + max_time * 0.01, len(machines) * 0.95, 
           f'Makespan = {max_time}', 
           fontsize=14, fontweight='bold', color='red',
           bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))
    
    # 设置背景色
    ax.set_facecolor('#FAFAFA')
    
    plt.tight_layout()
    plt.show()

def print_schedule_details(machine_orders: Dict[int, List[Operation]], 
                          start_times: Dict[str, int], 
                          makespan: int):
    """
    打印调度方案的详细信息
    
    Args:
        machine_orders: 每台机器的工序顺序
        start_times: 各工序的开始时间
        makespan: 最大完工时间
    """
    print("\n" + "="*60)
    print("调度方案详细信息")
    print("="*60)
    
    for machine in sorted(machine_orders.keys()):
        print(f"\n机器 M{machine} 的加工顺序:")
        operations = machine_orders[machine]
        
        for i, op in enumerate(operations):
            start_time = start_times[op.id]
            finish_time = start_time + op.processing_time
            print(f"  {i+1}. {op.id} (工件J{op.job_id}) | "
                  f"开始时间: {start_time}, 结束时间: {finish_time}, "
                  f"加工时间: {op.processing_time}")
    
    print(f"\n总完工时间 (Makespan): {makespan}")
    print("="*60)


if __name__ == "__main__":
    # 设置中文字体支持
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False

    # 运行三维实际案例
    solve_real_case(max_iterations=1)
